# LUCAS X PROMPT — Black × Silver

Website generator prompt AI dengan Gemini API. Termasuk frontend responsif, backend Express, salin prompt, JSON/teks, dan riwayat lokal browser.

## Persyaratan
- Node.js 20 atau lebih baru
- Gemini API key dari Google AI Studio
- Koneksi internet untuk memasang paket dan memanggil Gemini

## Menjalankan di komputer
1. Ekstrak ZIP ini.
2. Buka terminal di folder proyek.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Isi `GEMINI_API_KEY` di `.env` dengan API key milikmu. Jangan bagikan file `.env`.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000`.

## Menjalankan di Android
Cara termudah adalah memakai layanan hosting Node.js yang mendukung environment variables. Unggah folder proyek ke layanan tersebut, jalankan `npm install` dan `npm start`, lalu tambahkan `GEMINI_API_KEY` sebagai environment variable di dashboard hosting. Jangan unggah `.env` ke repositori publik.

## Keamanan
- API Key hanya dibaca backend melalui `process.env.GEMINI_API_KEY`.
- `.env` diabaikan oleh Git melalui `.gitignore`.
- API endpoint diberi rate limit dasar.
- Untuk penggunaan publik, tambahkan autentikasi pengguna, pembatasan biaya/kuota, dan proteksi penyalahgunaan sebelum membagikan link.

## Catatan
Kuota gratis Gemini bergantung pada model, project, wilayah, dan kebijakan Google yang dapat berubah. Aplikasi ini tidak menjanjikan kuota tanpa batas. Model default `gemini-flash-latest` dapat diganti melalui `GEMINI_MODEL` jika tidak tersedia di project.
