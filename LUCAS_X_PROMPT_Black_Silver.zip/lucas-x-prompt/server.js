import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { GoogleGenAI } from "@google/genai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const port = Number(process.env.PORT || 3000);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 12, standardHeaders: "draft-8", legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => {
  res.json({ configured: Boolean(process.env.GEMINI_API_KEY), model: process.env.GEMINI_MODEL || "gemini-flash-latest" });
});

app.post("/api/generate", async (req, res) => {
  try {
    const { mode, subject, scene, style, ratio, language, format, details } = req.body || {};
    const clean = (v, max = 1200) => String(v ?? "").trim().slice(0, max);
    const allowedModes = ["Foto AI", "Video AI", "Motion Control", "Foto Live", "Foto Pasangan"];
    const safeMode = allowedModes.includes(mode) ? mode : "Foto AI";
    const safeFormat = format === "JSON" ? "JSON" : "Teks";
    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: "API belum dipasang. Isi GEMINI_API_KEY di file .env pada server." });
    }
    if (!clean(subject, 500)) return res.status(400).json({ error: "Isi subjek utama terlebih dahulu." });

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const lang = language === "English" ? "English" : "Bahasa Indonesia";
    const instruction = `
Kamu adalah Lucas X Prompt, ahli prompt engineering untuk generator gambar dan video AI.
Buat prompt yang detail, koheren, spesifik, natural, dan siap disalin ke generator AI.
Jenis: ${safeMode}
Subjek: ${clean(subject, 500)}
Lokasi/adegan: ${clean(scene, 500)}
Gaya visual: ${clean(style, 300)}
Rasio: ${clean(ratio, 20)}
Detail tambahan: ${clean(details, 1500)}
Bahasa keluaran: ${lang}
Aturan:
- Jangan mengklaim menghasilkan gambar/video; tugasmu hanya menulis prompt.
- Untuk foto, perjelas framing, pose, pencahayaan, kamera, tekstur, dan konsistensi anatomi.
- Untuk video/motion control, jelaskan gerakan, kamera, kontinuitas frame, dan larangan menambah objek yang tidak diminta.
- Hindari instruksi yang saling bertentangan dan detail berlebihan yang tidak relevan.
- Jika identitas wajah perlu dipertahankan, tulis instruksi identity lock yang jelas tanpa menjanjikan akurasi absolut.
${safeFormat === "JSON" ? "Keluarkan JSON valid saja, tanpa markdown/code fence. Gunakan struktur objek dengan properti prompt, genre, style, composition, camera, lighting, scene, subject, motion, negative_prompt, aspect_ratio. Hilangkan properti yang tidak relevan." : "Keluarkan prompt siap pakai dalam paragraf dan bagian yang mudah dibaca. Jangan bungkus dalam JSON."}
`;
    const response = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || "gemini-flash-latest",
      contents: instruction,
      config: { temperature: 0.8 }
    });
    const output = response.text?.trim();
    if (!output) return res.status(502).json({ error: "Gemini tidak mengembalikan teks. Coba lagi." });
    res.json({ output });
  } catch (err) {
    console.error("Gemini request failed:", err?.message || err);
    const msg = String(err?.message || "");
    if (/API key|PERMISSION_DENIED|unauthorized|401|403/i.test(msg)) {
      return res.status(502).json({ error: "API Key ditolak atau belum memiliki izin Gemini API. Periksa key dan project di Google AI Studio." });
    }
    if (/quota|429|RESOURCE_EXHAUSTED/i.test(msg)) {
      return res.status(429).json({ error: "Kuota atau batas permintaan Gemini sedang tercapai. Tunggu sebentar atau periksa kuota akun." });
    }
    res.status(500).json({ error: "Terjadi kesalahan saat menghubungi Gemini. Periksa log server lalu coba lagi." });
  }
});

app.listen(port, () => console.log(`Lucas X Prompt berjalan di http://localhost:${port}`));
